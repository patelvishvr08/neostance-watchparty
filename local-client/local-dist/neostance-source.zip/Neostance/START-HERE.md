# Compact standalone source download

Videos and the generated client are separate. Install Node.js 24, run `node scripts/fetch-media.mjs`, then `npm install`, `npm run build`, and `npm start`. The complete submission ZIP already includes all videos and the prebuilt client.
