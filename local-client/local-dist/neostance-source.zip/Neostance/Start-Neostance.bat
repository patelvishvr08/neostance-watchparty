@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Install Node.js 24 LTS from https://nodejs.org and try again.
  pause
  exit /b 1
)
echo Neostance is starting. Open http://localhost:3000 in your browser.
node scripts/local-server.mjs
pause
